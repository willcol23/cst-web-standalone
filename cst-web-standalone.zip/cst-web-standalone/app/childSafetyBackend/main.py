from contextlib import asynccontextmanager

from dotenv import load_dotenv
from fastapi import FastAPI
from fastapi.middleware.cors import CORSMiddleware

load_dotenv()

try:
    from .api import routes_heatmap, routes_vault, routes_tracker, routes_communication, routes_alerts
    from child_safety_core.adapters import close_mongo_client, get_mongo_client
except ImportError:
    from api import routes_heatmap, routes_vault, routes_tracker, routes_communication, routes_alerts
    from child_safety_core.adapters import close_mongo_client, get_mongo_client


@asynccontextmanager
async def lifespan(app: FastAPI):
    await get_mongo_client().admin.command("ping")
    yield
    await close_mongo_client()


app = FastAPI(title="Child Safety API", version="1.0.0", lifespan=lifespan)

app.add_middleware(
    CORSMiddleware,
    allow_origins=["*"],
    allow_credentials=True,
    allow_methods=["*"],
    allow_headers=["*"],
)

app.include_router(routes_heatmap.router)
app.include_router(routes_vault.router)
app.include_router(routes_tracker.router)
app.include_router(routes_communication.router)
app.include_router(routes_alerts.router)

@app.get("/health")
async def health_check():
    return {"status": "healthy"}
